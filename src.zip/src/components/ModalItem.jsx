import React from "react";

/**
 * props:
 * - show (bool)
 * - title (string)
 * - fields: array of { name, label, type: 'text'|'textarea'|'select', options? }
 * - value: object (form)
 * - onChange: fn(newValue)
 * - onSubmit: fn()
 * - onClose: fn()
 */
export default function ModalItem({ show, title, fields = [], value = {}, onChange = () => {}, onSubmit = () => {}, onClose = () => {} }) {
  if (!show) return null;

  const handleChange = (name, val) => {
    onChange({ ...value, [name]: val });
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)",
      display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999
    }}>
      <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} style={{ width: 680, background: "#fff", padding: 20, borderRadius: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h5 style={{ margin: 0 }}>{title}</h5>
          <button type="button" onClick={onClose} style={{ border: "none", background: "transparent", fontSize: 20 }}>✕</button>
        </div>

        <div style={{ marginTop: 12 }}>
          {fields.map((f) => (
            <div key={f.name} style={{ marginBottom: 12 }}>
              <label style={{ display: "block", marginBottom: 6 }}>{f.label}</label>

              {f.type === "text" && (
                <input
                  className="form-control"
                  value={value[f.name] || ""}
                  onChange={(e) => handleChange(f.name, e.target.value)}
                />
              )}

              {f.type === "textarea" && (
                <textarea
                  className="form-control"
                  rows={f.rows || 3}
                  value={value[f.name] || ""}
                  onChange={(e) => handleChange(f.name, e.target.value)}
                />
              )}

              {f.type === "select" && (
                <select
                  className="form-control"
                  value={value[f.name] || f.options?.[0]}
                  onChange={(e) => handleChange(f.name, e.target.value)}
                >
                  {(f.options || []).map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              )}
            </div>
          ))}
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 6 }}>
          <button type="button" className="btn btn-outline" onClick={onClose}>Batal</button>
          <button type="submit" className="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  );
}
