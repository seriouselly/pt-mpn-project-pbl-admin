import React from "react";

/**
 * Props:
 * - variant: 'layanan' | 'testimoni'
 * - item: object
 * - onEdit, onDelete: callbacks
 */
export default function CardItem({ variant = "layanan", item = {}, onEdit = () => {}, onDelete = () => {} }) {
  if (variant === "testimoni") {
    return (
      <div style={{ background: "#fff", borderRadius: 12, padding: 16, boxShadow: "0 4px 14px rgba(0,0,0,0.06)" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ width: 64, height: 64, borderRadius: 12, overflow: "hidden", background: "#f0f0f0" }}>
            {item.foto ? <img src={item.foto} alt={item.nama} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <div style={{ padding: 12, color: "#888" }}>No Image</div>}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700 }}>{item.nama}</div>
            <div style={{ color: "#666", marginTop: 6 }}>{item.testimoni}</div>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 12 }}>
          <button className="btn btn-outline" onClick={onEdit}>Edit</button>
          <button className="btn btn-danger" onClick={onDelete}>Hapus</button>
        </div>
      </div>
    );
  }

  // layanan variant
  return (
    <div style={{ background: "#fff", borderRadius: 12, padding: 18, boxShadow: "0 4px 14px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ width: 48, height: 48, borderRadius: 10, background: "#eef4ff", display: "flex", alignItems: "center", justifyContent: "center" }}>📦</div>
          <div>
            <div style={{ fontWeight: 700 }}>{item.nama}</div>
            <div style={{ color: "#555", marginTop: 6 }}>{item.deskripsi}</div>
          </div>
        </div>

        <div>
          <span style={{
            padding: "6px 10px",
            borderRadius: 20,
            background: item.status === "Active" ? "#E6F9EC" : "#FCE8E8",
            color: item.status === "Active" ? "#16A249" : "#C03737",
            fontWeight: 700,
            fontSize: 12
          }}>{item.status || "Active"}</span>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
        <button className="btn btn-outline" style={{ flex: 1 }} onClick={onEdit}>✏ Edit</button>
        <button className="btn btn-danger" onClick={onDelete}>🗑</button>
      </div>
    </div>
  );
}
