import React from "react";
import DashboardLayout from "../components/layout/DashboardLayout";

function ProfilPerusahaan() {
  return (
    <DashboardLayout>
      <h1>Selamat Datang di Dashboard</h1>
      <p>Ini Profil Perusahaan.</p>
    </DashboardLayout>
  );
}

export default ProfilPerusahaan;
